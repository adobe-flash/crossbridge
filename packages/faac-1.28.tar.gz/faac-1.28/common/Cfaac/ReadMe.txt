+----------------------------------------------------------------+
|                                                                |
|                           Cfaac Readme                         |
|                           ------------                         |
|                                                                |
+----------------------------------------------------------------+

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY.

----------------------------------------------------------------------------

Cfaac is a set of classes to develop plugins (to import/export .aac/.mp4 files) with ease.

----------------------------------------------------------------------------

For suggestions, bugs report, etc., you can contact me at
ntnfrn_email-temp@yahoo.it
