
#warning parsing remapped file



int x;

#pragma clang __debug crash

int x;

