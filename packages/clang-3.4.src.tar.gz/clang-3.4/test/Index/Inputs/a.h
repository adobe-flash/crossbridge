#ifndef A_H
#define A_H
typedef int A;
#endif
