typedef float B;
