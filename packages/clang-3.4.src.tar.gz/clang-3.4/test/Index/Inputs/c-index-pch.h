#ifndef C_INDEX_PCH_H
#define C_INDEX_PCH_H

void foo(int i, float f);
extern int bar;

#endif // C_INDEX_PCH_H
