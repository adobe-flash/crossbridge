extern int global_var;

void foo_func(int param1);
void bar_func(void);

struct MyStruct {
  int field_var;
};
