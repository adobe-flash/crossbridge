int *getA();

