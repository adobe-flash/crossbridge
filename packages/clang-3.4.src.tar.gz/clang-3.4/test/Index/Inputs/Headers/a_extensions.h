int *getAExtensions();
