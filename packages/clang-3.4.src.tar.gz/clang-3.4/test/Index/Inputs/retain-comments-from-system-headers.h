#pragma clang system_header

/**
 * system_function
 * \param a Aaa.
 */
int system_function(int a);

