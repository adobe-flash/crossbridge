@interface A
- (int)instanceMethod1:(int)x;
+ (int)classMethod1:(double)d;
@end

@interface B
- (int)instanceMethod2:(int)x;
+ (int)classMethod2:(float)f;
@end

