#ifndef PREFIX_H
#define PREFIX_H
int foo(int);
#endif
