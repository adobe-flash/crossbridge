int *getFrameworkVersion();

