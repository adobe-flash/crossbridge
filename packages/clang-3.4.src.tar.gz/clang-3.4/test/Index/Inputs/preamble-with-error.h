typedef int Int;
enum FFF
extern Int *const www;
