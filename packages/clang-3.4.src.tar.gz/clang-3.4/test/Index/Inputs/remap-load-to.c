int foo(int parm1, float parm2) {
  return parm1 + parm2;
}
