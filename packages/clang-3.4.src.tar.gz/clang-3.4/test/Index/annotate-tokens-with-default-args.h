struct Foo {
  void m(Foo *f = 0);
};
