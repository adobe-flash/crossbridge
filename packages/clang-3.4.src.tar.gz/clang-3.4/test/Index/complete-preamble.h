namespace std {
  void wibble();
}

namespace std {
}
