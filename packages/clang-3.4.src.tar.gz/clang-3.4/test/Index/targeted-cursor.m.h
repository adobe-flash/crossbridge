
@interface I

-(void)mm:(void (^)(I*))block;
-(void)mm2:(I*)i;

@end
