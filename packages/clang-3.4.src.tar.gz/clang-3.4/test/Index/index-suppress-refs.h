
@interface I
@end

@interface B
@end

@protocol P
@end
