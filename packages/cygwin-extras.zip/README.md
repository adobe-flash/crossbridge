INSTALL GUIDE
=============

1. Install Java JDK / JRE 8 if not available
2. Install Cygwin using *setup-x86.exe* or *install.bat* (Optional step)
   (You can use your own installation, just make sure *libuuid1* is installed and run.bat path is changed)
3. Launch 'run.bat' from dos prompt
4. Run 'cd $FLASCC_ROOT/samples && make' from Cygwin shell

Expected folder structure:

\CROSSBRIDGE
  \install.bat
  \run.bat
  \cygwin
  \docs
  \samples
  \sdk

Note: CrossBridge SDK Compiled using Cygwin DLL 1.7.29 and Java 8

VPMedia