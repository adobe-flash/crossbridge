struct_rename

b = struct_rename.Bar();

