extend_variable

if (Foo.Bar != 42)
    error
endif

