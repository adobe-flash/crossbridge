from abstract_virtual import *


d = D()

e = E()
