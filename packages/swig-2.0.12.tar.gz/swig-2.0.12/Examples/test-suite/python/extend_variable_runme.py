from extend_variable import *

if Foo.Bar != 42:
    raise RuntimeError
