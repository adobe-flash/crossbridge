import using2

if using2.spam(37) != 37:
    raise RuntimeError
