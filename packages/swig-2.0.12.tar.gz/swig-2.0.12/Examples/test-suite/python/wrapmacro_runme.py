import wrapmacro

a = 2
b = -1
wrapmacro.maximum(a,b)
wrapmacro.maximum(a/7.0, -b*256)
wrapmacro.GUINT16_SWAP_LE_BE_CONSTANT(1)
