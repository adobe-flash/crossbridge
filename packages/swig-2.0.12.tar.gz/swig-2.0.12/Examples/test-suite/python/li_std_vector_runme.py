from li_std_vector import *

if typedef_test(101) != 101:
    raise RuntimeError
