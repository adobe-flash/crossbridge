/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* machine generated file via utils/exactgc.as -- do not edit */

#define avmshell_AbstractBaseClass_isExactInterlock 1
#define avmshell_AbstractBaseObject_isExactInterlock 1
#define avmshell_AbstractRestrictedBaseClass_isExactInterlock 1
#define avmshell_AbstractRestrictedBaseObject_isExactInterlock 1
#define avmshell_CheckBaseClass_isExactInterlock 1
#define avmshell_CheckBaseObject_isExactInterlock 1
#define avmshell_DebugCLI_isExactInterlock 1
#define avmshell_NativeBaseClass_isExactInterlock 1
#define avmshell_NativeBaseObject_isExactInterlock 1
#define avmshell_NativeSubclassOfAbstractBaseClass_isExactInterlock 1
#define avmshell_NativeSubclassOfAbstractBaseObject_isExactInterlock 1
#define avmshell_NativeSubclassOfAbstractRestrictedBaseClass_isExactInterlock 1
#define avmshell_NativeSubclassOfAbstractRestrictedBaseObject_isExactInterlock 1
#define avmshell_NativeSubclassOfRestrictedBaseClass_isExactInterlock 1
#define avmshell_NativeSubclassOfRestrictedBaseObject_isExactInterlock 1
#define avmshell_RestrictedBaseClass_isExactInterlock 1
#define avmshell_RestrictedBaseObject_isExactInterlock 1
#define avmshell_ShellToplevel_isExactInterlock 1
#define avmshell_SystemClass_isExactInterlock 1

