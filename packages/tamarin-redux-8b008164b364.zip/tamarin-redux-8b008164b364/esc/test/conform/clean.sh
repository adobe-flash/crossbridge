rm -f `find . -name "*.log" -o -name "*.abc" -o -name "*~"`
