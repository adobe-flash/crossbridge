
double SOR_num_flops(int M, int N, int num_iterations);
void SOR_execute(int M, int N,double omega, double **G, int num_iterations);

