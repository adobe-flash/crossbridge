
void FFT_transform(int N, double *data);
void FFT_inverse(int N, double *data);
void FFT_bitreverse(int N, double *data);
double FFT_num_flops(int N);
