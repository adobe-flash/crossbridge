<?php

require "example.php";

?>
