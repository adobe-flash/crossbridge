#include <stdio.h>


void endLine(){
    printf("\n");
}

/////////


int lexicalKeywords0(int as){
    printf("%d ", as);
    return as;
}

int lexicalKeywords1(int extends){
    printf("%d ", extends);
    return extends;
}

int lexicalKeywords2(int finally){
    printf("%d ", finally);
    return finally;
}

int lexicalKeywords3(int function){
    printf("%d ", function);
    return function;
}

int lexicalKeywords4(int implements){
    printf("%d ", implements);
    return implements;
}

int lexicalKeywords5(int import){
    printf("%d ", import);
    return import;
}

int lexicalKeywords6(int in){
    printf("%d ", in);
    return in;
}

int lexicalKeywords7(int instanceof){
    printf("%d ", instanceof);
    return instanceof;
}

int lexicalKeywords8(int interface){
    printf("%d ", interface);
    return interface;
}

int lexicalKeywords9(int internal){
    printf("%d ", internal);
    return internal;
}

int lexicalKeywords10(int is){
    printf("%d ", is);
    return is;
}

int lexicalKeywords11(int native){
    printf("%d ", native);
    return native;
}

int lexicalKeywords12(int null){
    printf("%d ", null);
    return null;
}

int lexicalKeywords13(int package){
    printf("%d ", package);
    return package;
}

int lexicalKeywords14(int super){
    printf("%d ", super);
    return super;
}

int lexicalKeywords15(int to){
    printf("%d ", to);
    return to;
}

int lexicalKeywords16(int use){
    printf("%d ", use);
    return use;
}

int lexicalKeywords17(int var){
    printf("%d ", var);
    return var;
}

int lexicalKeywords18(int with){
    printf("%d ", with);
    return with;
}

int syntacticKeywords0(int each){
    printf("%d ", each);
    return each;
}

int syntacticKeywords1(int get){
    printf("%d ", get);
    return get;
}

int syntacticKeywords2(int set){
    printf("%d ", set);
    return set;
}

int syntacticKeywords3(int include){
    printf("%d ", include);
    return include;
}

int syntacticKeywords4(int dynamic){
    printf("%d ", dynamic);
    return dynamic;
}

int syntacticKeywords5(int final){
    printf("%d ", final);
    return final;
}

int syntacticKeywords6(int native){
    printf("%d ", native);
    return native;
}

int syntacticKeywords7(int override){
    printf("%d ", override);
    return override;
}

int futureReservedWords0(int abstract){
    printf("%d ", abstract);
    return abstract;
}

int futureReservedWords1(int boolean){
    printf("%d ", boolean);
    return boolean;
}

int futureReservedWords2(int byte){
    printf("%d ", byte);
    return byte;
}

int futureReservedWords3(int cast){
    printf("%d ", cast);
    return cast;
}

int futureReservedWords4(int debugger){
    printf("%d ", debugger);
    return debugger;
}

int futureReservedWords5(int intrinsic){
    printf("%d ", intrinsic);
    return intrinsic;
}

int futureReservedWords6(int prototype){
    printf("%d ", prototype);
    return prototype;
}

int futureReservedWords7(int synchronized){
    printf("%d ", synchronized);
    return synchronized;
}

int futureReservedWords8(int throws){
    printf("%d ", throws);
    return throws;
}

int futureReservedWords9(int to){
    printf("%d ", to);
    return to;
}

int futureReservedWords10(int transient){
    printf("%d ", transient);
    return transient;
}

int futureReservedWords11(int type){
    printf("%d ", type);
    return type;
}
