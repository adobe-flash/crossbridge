
int square(int a);

template<class T> class List {
public:
    List<T> sublist(int start, int end){ List l; return l;};
};
