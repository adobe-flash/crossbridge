#include "example.h"

using namespace std;

int square(int a)
{
    List<int> L;
	L.sublist(1,2);
    return a * a;
}