
void set_callback(int (*func)());
void set_callback2(int (*funct)(int, double));
void set_callback3(double (*func)());
void do_call();
