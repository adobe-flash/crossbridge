#include <stdio.h>
#include "example.h"

void printNumber(int i){
    printf("printNumber: 4==%d\n", i);
}

void printNumber2(int i){
    printf("printNumber2: 4==%d\n", i);
}