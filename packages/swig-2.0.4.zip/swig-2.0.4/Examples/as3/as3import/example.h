

void printNumber(int i);
void printNumber2(int i);
