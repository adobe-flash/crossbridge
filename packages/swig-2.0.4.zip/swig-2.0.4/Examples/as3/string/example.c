/* File : example.c */
#include <stdio.h>

void print_str(char *str) {
    printf("%s\n", str);
}

