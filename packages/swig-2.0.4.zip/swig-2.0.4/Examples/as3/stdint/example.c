/* File : example.c */
#include <stdint.h>

/* Some global variables */
int32_t a;
int_least16_t b;
int_fast8_t c;
uint8_t d;
intptr_t e;


