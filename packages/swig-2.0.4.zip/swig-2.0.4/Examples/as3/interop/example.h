/* File : example.h */

#include <cstdio>
#include <iostream>

class BaseClass
{
public:
	BaseClass()/*{}*/;

	virtual ~BaseClass() {}
};
