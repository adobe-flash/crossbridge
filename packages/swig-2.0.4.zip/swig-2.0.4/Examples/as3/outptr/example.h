/*
 * A sample C library for working with integer arrays
 */

void reverseArray(int* in, int* out, int length);
void incrementArray(int* in, int* out, int length);
