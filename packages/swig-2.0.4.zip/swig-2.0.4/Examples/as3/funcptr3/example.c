/* File : example.c */
#include "example.h"

snes_audio_chunk_t foo;

void set_blah(blah x) {}
void snes_set_audio_chunk( void (*chunk)(int *a, int b)) {}
