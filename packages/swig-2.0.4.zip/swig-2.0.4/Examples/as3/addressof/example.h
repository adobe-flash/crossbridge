struct Bar {
	int num;
};

void printPointer(struct Bar *number);
