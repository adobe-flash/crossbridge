/* File : example.c */

/* Returns values in the x and y pointers */
void getpoint(int *x, int *y) {
    *x = 1;
    *y = 2;
}

