This directory contains the SGI version of the Olden benchmark that we
used for our ASPLOS-VII paper "Compiler-Based Prefetching for
Recursive Data Structures". The following are the commands used for
the experiments:

	bh	4096 1
	bisort	250000 1
	em3d	2000 100 75 1
	health	5 500
	mst	512 1
	perimeter 12 1
	power
	treeadd	20 1
	tsp	100000 1
	voronoi 20000 1
