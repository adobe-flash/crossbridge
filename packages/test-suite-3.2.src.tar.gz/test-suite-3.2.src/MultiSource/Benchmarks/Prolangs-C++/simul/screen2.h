class cursor_controller2: public cursor_controller {
public:
  void normal();
  void high_intensity();
  void blink();
  void reverse();
  void invisible();
};

