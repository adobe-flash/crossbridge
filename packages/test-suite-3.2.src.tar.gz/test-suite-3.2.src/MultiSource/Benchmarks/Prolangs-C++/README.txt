These benchmarks were downloaded from:
http://www.prolangs.rutgers.edu/public.html

