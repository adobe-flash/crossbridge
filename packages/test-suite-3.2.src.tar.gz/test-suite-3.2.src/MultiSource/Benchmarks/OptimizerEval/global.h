#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

typedef void (*FunPar)(int *);

