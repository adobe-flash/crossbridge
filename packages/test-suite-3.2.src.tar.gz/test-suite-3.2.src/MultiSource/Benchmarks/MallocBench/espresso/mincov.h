/* exported */
extern sm_row *sm_minimum_cover();
