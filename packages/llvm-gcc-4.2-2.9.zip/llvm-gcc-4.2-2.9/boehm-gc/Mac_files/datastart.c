/*
	datastart.c
	
	A hack to get the extent of global data for the Macintosh.
	
	by Patrick C. Beard.
 */

long __datastart;
