extern void do_print();

int main() {
  do_print();
  return 0;
}
