#include <stdio.h>
void do_print() {
  printf("do print called\n");
}
