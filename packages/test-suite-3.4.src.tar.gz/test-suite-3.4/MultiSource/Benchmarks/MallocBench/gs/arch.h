#define big_endian 0
#define ints_are_short 0
