Obtained from:
http://cag.csail.mit.edu/versabench/benchmarks.html

This contains a subset of the programs and some are hacked to run
long enough.
