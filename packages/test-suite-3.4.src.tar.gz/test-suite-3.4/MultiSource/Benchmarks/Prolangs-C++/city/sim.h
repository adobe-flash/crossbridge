// sim.h

#ifndef _sim_h
#define _sim_h

#define TRUE 1
#define FALSE 0

class light;
class direction;
class roadlet;
class vehicle;
//class car : public vehicle;
class car;
// class truck : public vehicle;
class truck;
// class intersection_roadlet : public roadlet;
class intersection_roadlet;


#endif
