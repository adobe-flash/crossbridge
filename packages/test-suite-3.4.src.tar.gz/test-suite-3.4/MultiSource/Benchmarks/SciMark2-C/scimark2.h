
#ifndef SCIMARK2_H
#define SCIMARK2_H

#define VERSION 2.0

#ifndef NULL 
#define NULL 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif



#endif

